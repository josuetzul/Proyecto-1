﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Facturacion__proyecto_
{
    class Datos
    {
        static void Main(string[] args)
        {
            //while para que no se cierre el programa cuando hay un error
            while (true)
            {
                //Imprimir la parte superior de la factura
                Imprimir("TIENDAS MÁS", 984512 - 1);

                //numero de factura
                int n_factura = 0;
                int total_facturas = 0;


                //Ciclo de facturación para aumentar la cantidad de facturas
                int opcion = 1;
                while (opcion == 1)
                {
                    //Facturación
                    Console.Clear();

                    Console.WriteLine("FACTURACIÓN \nIngrese datos \n");

                    //Declaración de las variables a utilizar
                    int codigo, cantidad_t = 0, cantidad_esp, metodo_pago, nit_cliente;
                    double precio_uni = 0, precio_subtotal, total = 0, puntos_esp, puntos_totales_cliente = 0, puntos_totales = 0, puntos_totales_aux;
                    string nombre_cliente, correo_cliente, continuar = "s", resumen_producto, resumen_final = "", producto = "";

                    //Solicitar NIT
                    Console.Write("NIT: ");
                    try
                    {
                        nit_cliente = Convert.ToInt32(Console.ReadLine());

                        //Solicitar nombre
                        Console.Write("Nombre: ");

                        nombre_cliente = Convert.ToString(Console.ReadLine());

                        //Solicitar correo
                        Console.Write("Correo electrónico: ");

                        correo_cliente = Convert.ToString(Console.ReadLine());

                        //Ciclo de ingreso de productos
                        while (continuar == "s")
                        {
                            //Ingreso código del producto
                            Console.Write("Código del producto: ");
                            try
                            {   //Validación de que los códigos ingresados existan
                                codigo = Convert.ToInt32(Console.ReadLine());
                                if (codigo < 001 || codigo > 005)
                                {
                                    FormatException create = new FormatException();
                                }
                                else
                                {
                                    //Identificador de cada código
                                    switch (codigo)
                                    {
                                        case 001:
                                            producto = "Libra de azúcar";
                                            precio_uni = 10.80;
                                            break;

                                        case 002:

                                            producto = "Libra de arroz";
                                            precio_uni = 3.80;
                                            break;
                                        case 003:

                                            producto = "Galleta GAMA";
                                            precio_uni = 1.10;
                                            break;
                                        case 004:

                                            producto = "Coca Cola";
                                            precio_uni = 17.00;
                                            break;
                                        case 005:

                                            producto = "Libra de café";
                                            precio_uni = 50.00;
                                            break;
                                        default:
                                            producto = "";
                                            Console.WriteLine("Ingrese un número de código válido");
                                            break;
                                    }
                                }

                                //Ingreso cantidad de producto 
                                Console.Write("Cantidad: ");

                                //Validación de que la cantidad sea válida
                                cantidad_esp = Convert.ToInt32(Console.ReadLine());
                                if (cantidad_esp < 1)
                                {
                                    FormatException create = new FormatException();
                                }

                                //Sumatoria de total de productos llevados
                                cantidad_t = cantidad_t + cantidad_esp;

                                //SubTotal
                                precio_subtotal = precio_uni * cantidad_esp;

                                //Total
                                total = total + precio_subtotal;

                                //Resumen de producto
                                resumen_producto = $"{producto}: {cantidad_esp} x Q.{precio_uni} - Q.{precio_subtotal} \n";

                                //Resumen final de productos
                                resumen_final = resumen_final + resumen_producto;

                                //Preguntar si se va a ingresar otro producto
                                Console.Write("Desea agregar otro producto? s/n  ");
                                continuar = Convert.ToString(Console.ReadLine());
                                continuar = continuar.ToLower();
                            }
                            catch
                            {
                                Console.WriteLine("Ingrese un valor válido;");
                            }
                        }

                        //Fin del ingreso de productos
                        Console.Clear();

                        //Fin de la factura e incremento
                        n_factura++;
                        total_facturas = n_factura;

                        //Impresión de factura
                        Imprimir("TIENDAS MÁS", 984512 - 1);
                        Console.WriteLine($"N°. factura: {n_factura}");
                        Console.WriteLine($"\nDatos cliente:\nNIT: {nit_cliente}\nNombre: {nombre_cliente}\nCorreo electrónico: {correo_cliente} \n");

                        Console.WriteLine(resumen_final);
                        Console.WriteLine($"El total de la factura es: Q.{total}.\nLLeva {cantidad_t} productos.\n ");
                        Console.ReadKey();
                        Console.Clear();

                        //Elección método de pago
                        Console.WriteLine("Métodos de pago: \n1) Tarjeta de crédito o débito \n2) Efectivo");
                        Console.Write("Ingrese el método de pago: ");
                        metodo_pago = Convert.ToInt32(Console.ReadLine());

                        //Acumulación de puntos
                        if (metodo_pago == 1)
                        {
                            if (total > 10 && total <= 50)
                            {
                                puntos_esp = 1;
                                puntos_totales_cliente = total / 10;
                                puntos_totales_cliente = puntos_totales_cliente * puntos_esp;
                                Console.WriteLine($"Acumuló {puntos_totales_cliente} puntos");
                            }
                            else if (total > 50 && total <= 100)
                            {
                                puntos_esp = 2;
                                puntos_totales_cliente = total / 10;
                                puntos_totales_cliente = puntos_totales_cliente * puntos_esp;
                                Console.WriteLine($"Acumuló {puntos_totales_cliente} puntos");
                            }
                            else if (total > 100)
                            {
                                puntos_esp = 3;
                                puntos_totales_cliente = total / 10;
                                puntos_totales_cliente = puntos_totales_cliente * puntos_esp;
                                Console.WriteLine($"Acumuló {puntos_totales_cliente} puntos");
                            }
                        }

                        //Acumulación de puntos totales 
                        puntos_totales = puntos_totales + puntos_totales_cliente;
                        puntos_totales_aux = puntos_totales;

                        //Menú
                        Console.WriteLine("1. FACTURACIÓN");
                        Console.WriteLine("2. REPORTES DE FACTURACIÓN");
                        Console.WriteLine("3. SALIR");
                        Console.Write("Ingrese la opción que desea hacer: ");
                        try
                        {
                            //validación que la opcion elegida exista
                            opcion = Convert.ToInt32(Console.ReadLine());
                            if (opcion != 1 || opcion != 2)
                            {
                                FormatException create = new FormatException();
                            }

                        }
                        catch
                        {
                            Console.WriteLine("Ingrese una opción válida");
                            Console.ReadKey();
                            Console.Clear();
                        }
                    }
                    catch
                    {
                        Console.WriteLine("Ingrese un dato válido");
                    }



                    //Opciones de menú
                    switch (opcion)
                    {
                        case 2:
                            //código
                            Console.Clear();
                            Console.WriteLine($"La cantidad de facturas generadas fueron: {n_factura}");
                            Console.WriteLine($"La cantidad de puntos generados fueron: {puntos_totales}");
                            Console.WriteLine($"El total de productos vendidos son: {cantidad_t}");
                            Console.ReadKey();
                            Console.Clear();
                            break;
                        case 3:

                            //Salir de consola
                            Console.Clear();
                            Console.WriteLine("Feliz dia");
                            Console.WriteLine("Presione cualquier botón para salir");
                            Console.ReadKey();
                            Environment.Exit(0);
                            break;
                        default:
                            break;
                    }
                }
            }
        }

            static void Imprimir(string nombre, int nit)
            {
                Console.WriteLine($"{nombre} - {nit}");
                //nombre supermercado, nit supermercado

                //Obtener la fecha actual del sistema.
                DateTime aDate = DateTime.Now;

                //Formato en que se imprime la fecha.
                Console.WriteLine(aDate.ToString("dd/M/yyyy  HH:mm:ss"));
            }
        }
    }